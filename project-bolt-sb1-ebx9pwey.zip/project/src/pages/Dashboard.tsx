import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { Plus, Star, Package, ArrowUpDown, Settings, MapPin, Calendar } from 'lucide-react'
import { useAuthContext } from '../contexts/AuthContext'
import { supabase } from '../lib/supabase'

interface Profile {
  id: string
  username: string
  full_name: string
  points_balance: number
  bio: string
  location: string
  created_at: string
}

interface UserItem {
  id: string
  title: string
  images: string[]
  category: string
  status: string
  points_value: number
  created_at: string
}

interface SwapRequest {
  id: string
  status: string
  created_at: string
  requested_item: {
    title: string
    images: string[]
  }
  offered_item?: {
    title: string
    images: string[]
  }
  points_offered?: number
}

export function Dashboard() {
  const { user } = useAuthContext()
  const [profile, setProfile] = useState<Profile | null>(null)
  const [userItems, setUserItems] = useState<UserItem[]>([])
  const [swapRequests, setSwapRequests] = useState<SwapRequest[]>([])
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('items')

  useEffect(() => {
    if (user) {
      fetchDashboardData()
    }
  }, [user])

  const fetchDashboardData = async () => {
    try {
      // Fetch profile
      const { data: profileData } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user?.id)
        .single()

      if (profileData) {
        setProfile(profileData)
      }

      // Fetch user items
      const { data: itemsData } = await supabase
        .from('items')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false })

      if (itemsData) {
        setUserItems(itemsData)
      }

      // Fetch swap requests
      const { data: swapsData } = await supabase
        .from('swap_requests')
        .select(`
          *,
          requested_item:items!swap_requests_requested_item_id_fkey(title, images),
          offered_item:items!swap_requests_offered_item_id_fkey(title, images)
        `)
        .or(`requester_id.eq.${user?.id},item_owner_id.eq.${user?.id}`)
        .order('created_at', { ascending: false })

      if (swapsData) {
        setSwapRequests(swapsData as any)
      }
    } catch (error) {
      console.error('Error fetching dashboard data:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Profile Header */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center">
                <span className="text-2xl font-bold text-emerald-600">
                  {profile?.full_name?.charAt(0) || profile?.username?.charAt(0) || 'U'}
                </span>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">{profile?.full_name || profile?.username}</h1>
                <p className="text-gray-600">@{profile?.username}</p>
                {profile?.location && (
                  <div className="flex items-center text-gray-500 text-sm mt-1">
                    <MapPin className="w-4 h-4 mr-1" />
                    <span>{profile.location}</span>
                  </div>
                )}
              </div>
            </div>
            <div className="flex items-center space-x-6 mt-4 md:mt-0">
              <div className="text-center">
                <div className="text-2xl font-bold text-emerald-600">{profile?.points_balance || 0}</div>
                <div className="text-sm text-gray-500">Points</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900">{userItems.length}</div>
                <div className="text-sm text-gray-500">Items Listed</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900">{swapRequests.length}</div>
                <div className="text-sm text-gray-500">Swap Requests</div>
              </div>
              <Link
                to="/settings"
                className="flex items-center space-x-2 bg-gray-100 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-200 transition-colors"
              >
                <Settings className="w-4 h-4" />
                <span>Settings</span>
              </Link>
            </div>
          </div>
          {profile?.bio && (
            <div className="mt-4 pt-4 border-t border-gray-200">
              <p className="text-gray-600">{profile.bio}</p>
            </div>
          )}
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Link
            to="/add-item"
            className="bg-emerald-600 text-white p-6 rounded-lg hover:bg-emerald-700 transition-colors"
          >
            <div className="flex items-center space-x-3">
              <Plus className="w-8 h-8" />
              <div>
                <h3 className="font-semibold">List New Item</h3>
                <p className="text-emerald-100 text-sm">Add items to swap</p>
              </div>
            </div>
          </Link>
          <Link
            to="/browse"
            className="bg-white border border-gray-200 p-6 rounded-lg hover:shadow-md transition-shadow"
          >
            <div className="flex items-center space-x-3">
              <Package className="w-8 h-8 text-gray-600" />
              <div>
                <h3 className="font-semibold text-gray-900">Browse Items</h3>
                <p className="text-gray-500 text-sm">Find items to swap</p>
              </div>
            </div>
          </Link>
          <div className="bg-white border border-gray-200 p-6 rounded-lg">
            <div className="flex items-center space-x-3">
              <Star className="w-8 h-8 text-yellow-500" />
              <div>
                <h3 className="font-semibold text-gray-900">Member Since</h3>
                <p className="text-gray-500 text-sm">
                  {profile?.created_at ? new Date(profile.created_at).toLocaleDateString() : 'N/A'}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-6">
              <button
                onClick={() => setActiveTab('items')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'items'
                    ? 'border-emerald-500 text-emerald-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                My Items ({userItems.length})
              </button>
              <button
                onClick={() => setActiveTab('swaps')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'swaps'
                    ? 'border-emerald-500 text-emerald-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                Swap Requests ({swapRequests.length})
              </button>
            </nav>
          </div>

          <div className="p-6">
            {activeTab === 'items' && (
              <div>
                {userItems.length === 0 ? (
                  <div className="text-center py-12">
                    <Package className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No items listed yet</h3>
                    <p className="text-gray-500 mb-4">Start by listing your first item to begin swapping.</p>
                    <Link
                      to="/add-item"
                      className="bg-emerald-600 text-white px-6 py-2 rounded-lg hover:bg-emerald-700 transition-colors"
                    >
                      List Your First Item
                    </Link>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {userItems.map((item) => (
                      <div key={item.id} className="border border-gray-200 rounded-lg overflow-hidden">
                        <div className="aspect-square bg-gray-200">
                          {item.images && item.images.length > 0 ? (
                            <img
                              src={item.images[0]}
                              alt={item.title}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-gray-400">
                              No Image
                            </div>
                          )}
                        </div>
                        <div className="p-4">
                          <h3 className="font-semibold text-gray-900 mb-2">{item.title}</h3>
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-gray-500 capitalize">{item.category}</span>
                            <span className="text-emerald-600 font-semibold">{item.points_value} pts</span>
                          </div>
                          <div className="mt-2 flex justify-between items-center">
                            <span
                              className={`inline-block text-xs px-2 py-1 rounded-full capitalize ${
                                item.status === 'available'
                                  ? 'bg-green-100 text-green-800'
                                  : item.status === 'pending'
                                  ? 'bg-yellow-100 text-yellow-800'
                                  : 'bg-gray-100 text-gray-800'
                              }`}
                            >
                              {item.status}
                            </span>
                            <span className="text-xs text-gray-400">
                              {new Date(item.created_at).toLocaleDateString()}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {activeTab === 'swaps' && (
              <div>
                {swapRequests.length === 0 ? (
                  <div className="text-center py-12">
                    <ArrowUpDown className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No swap requests yet</h3>
                    <p className="text-gray-500 mb-4">Browse items and make your first swap request.</p>
                    <Link
                      to="/browse"
                      className="bg-emerald-600 text-white px-6 py-2 rounded-lg hover:bg-emerald-700 transition-colors"
                    >
                      Browse Items
                    </Link>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {swapRequests.map((swap) => (
                      <div key={swap.id} className="border border-gray-200 rounded-lg p-4">
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <h3 className="font-semibold text-gray-900 mb-2">
                              {swap.requested_item?.title}
                            </h3>
                            <div className="flex items-center space-x-4">
                              <span
                                className={`inline-block text-xs px-2 py-1 rounded-full capitalize ${
                                  swap.status === 'pending'
                                    ? 'bg-yellow-100 text-yellow-800'
                                    : swap.status === 'accepted'
                                    ? 'bg-green-100 text-green-800'
                                    : swap.status === 'rejected'
                                    ? 'bg-red-100 text-red-800'
                                    : 'bg-blue-100 text-blue-800'
                                }`}
                              >
                                {swap.status}
                              </span>
                              <span className="text-sm text-gray-500">
                                {new Date(swap.created_at).toLocaleDateString()}
                              </span>
                            </div>
                            {swap.offered_item ? (
                              <p className="text-sm text-gray-600 mt-2">
                                Offered: {swap.offered_item.title}
                              </p>
                            ) : swap.points_offered ? (
                              <p className="text-sm text-gray-600 mt-2">
                                Offered: {swap.points_offered} points
                              </p>
                            ) : null}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}