import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables')
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          username: string
          full_name: string | null
          avatar_url: string | null
          points_balance: number
          bio: string | null
          location: string | null
          is_admin: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          username: string
          full_name?: string | null
          avatar_url?: string | null
          points_balance?: number
          bio?: string | null
          location?: string | null
          is_admin?: boolean
        }
        Update: {
          username?: string
          full_name?: string | null
          avatar_url?: string | null
          points_balance?: number
          bio?: string | null
          location?: string | null
          is_admin?: boolean
        }
      }
      items: {
        Row: {
          id: string
          user_id: string
          title: string
          description: string
          category: string
          item_type: string
          size: string
          condition: string
          tags: string[]
          images: string[]
          points_value: number
          status: 'available' | 'pending' | 'swapped' | 'removed'
          admin_approved: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          user_id: string
          title: string
          description: string
          category: string
          item_type: string
          size: string
          condition: string
          tags?: string[]
          images?: string[]
          points_value?: number
          status?: 'available' | 'pending' | 'swapped' | 'removed'
          admin_approved?: boolean
        }
        Update: {
          title?: string
          description?: string
          category?: string
          item_type?: string
          size?: string
          condition?: string
          tags?: string[]
          images?: string[]
          points_value?: number
          status?: 'available' | 'pending' | 'swapped' | 'removed'
          admin_approved?: boolean
        }
      }
      swap_requests: {
        Row: {
          id: string
          requester_id: string
          item_owner_id: string
          requested_item_id: string
          offered_item_id: string | null
          points_offered: number | null
          message: string | null
          status: 'pending' | 'accepted' | 'rejected' | 'completed'
          created_at: string
          updated_at: string
        }
        Insert: {
          requester_id: string
          item_owner_id: string
          requested_item_id: string
          offered_item_id?: string | null
          points_offered?: number | null
          message?: string | null
          status?: 'pending' | 'accepted' | 'rejected' | 'completed'
        }
        Update: {
          status?: 'pending' | 'accepted' | 'rejected' | 'completed'
          message?: string | null
        }
      }
    }
  }
}